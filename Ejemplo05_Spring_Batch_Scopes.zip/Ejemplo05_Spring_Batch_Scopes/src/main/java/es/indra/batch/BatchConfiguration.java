package es.indra.batch;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import es.indra.models.Producto;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

	@Autowired // DI
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Autowired
	private DataSource dataSource;

	/*
	 * Estos scopes permiten inicialización perezosa (lazy) y el acceso seguro a
	 * parámetros y contextos relevantes durante la ejecución del batch.
	 */

	@Bean
	@JobScope
	// Se usa para beans cuyo ciclo de vida e instancia debe ser único por cada job.
	// Útil, por ejemplo, para listeners u objetos auxiliares del job:
	public JobListener jobListener() {
		return new JobListener();
	}

	// Crear un job
	@Bean // convierte el objeto Java en un bean de Spring
	public Job crearJob() {
		return jobBuilderFactory.get("productosJob").listener(jobListener()).flow(step1()).end().build();
	}

	// Crear un step
	@Bean
	public Step step1() {
		return stepBuilderFactory.get("step1").<Producto, Producto>chunk(2) // nº de registros que leemos en cada bloque
				.reader(reader()).processor(procesor()).writer(writer()).build();
	}

	// Crear el reader
	@Bean
	@StepScope
	// Se recomienda en readers, procesadores y writers que dependen de parámetros o
	// contexto del step
	public FlatFileItemReader<Producto> reader() {
		return new FlatFileItemReaderBuilder<Producto>().name("productoItemReader")
				.resource(new ClassPathResource("data.csv")).delimited().names("id", "descripcion", "precio")
				.fieldSetMapper(new BeanWrapperFieldSetMapper<Producto>() {
					{
						setTargetType(Producto.class);
					}
				}).build();
	}

	// Crear un procesor
	@Bean
	public ProcesoProducto procesor() {
		return new ProcesoProducto();
	}

	// Crear el writer
	@Bean
	public JdbcBatchItemWriter<Producto> writer() {
		return new JdbcBatchItemWriterBuilder<Producto>()
				// las propiedades del objeto producto son los parametros para insertar la query
				.itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
				.sql("INSERT INTO productos (id, descripcion, precio) VALUES (:id, :descripcion, :precio)")
				.dataSource(dataSource).build();
	}

}
