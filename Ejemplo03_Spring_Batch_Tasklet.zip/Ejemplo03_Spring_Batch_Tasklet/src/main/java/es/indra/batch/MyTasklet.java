package es.indra.batch;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Component;

@Component
public class MyTasklet implements Tasklet{

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		
		// Recuperar los parametros
		Long time = (Long) chunkContext.getStepContext().getJobParameters().get("time");
		System.out.println("Parametro recibido: " + time);
		
		
		System.out.println("Ejecutando el tasklet");
		return RepeatStatus.FINISHED;
	}

}
