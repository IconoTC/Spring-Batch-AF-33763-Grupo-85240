package es.indra.batch;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.job.builder.FlowBuilder;
import org.springframework.batch.core.job.flow.Flow;
import org.springframework.batch.core.job.flow.support.SimpleFlow;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {
	
	@Autowired  // DI
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	// Crear un job
	@Bean   // convierte el objeto Java en un bean de Spring
	public Job crearJob() {
		return jobBuilderFactory.get("paralellJob")
				.start(new FlowBuilder<SimpleFlow>("jobFlow")
						.split(taskExecutor())
						.add(flow1(), flow2(), flow3())
						.build())
				.end()
				.build();
	}
	
	@Bean
	public Step step1() {
		return stepBuilderFactory.get("step1")
				.tasklet((contribution, chunkContext) -> {
					System.out.println("Ejecutando Step1");
					return RepeatStatus.FINISHED;
				})
				.build();
	}
	
	@Bean
	public Step step2() {
		return stepBuilderFactory.get("step2")
				.tasklet((contribution, chunkContext) -> {
					System.out.println("Ejecutando Step2");
					return RepeatStatus.FINISHED;
				})
				.build();
	}
	
	@Bean
	public Step step3() {
		return stepBuilderFactory.get("step3")
				.tasklet((contribution, chunkContext) -> {
					System.out.println("Ejecutando Step3");
					return RepeatStatus.FINISHED;
				})
				.build();
	}
	
	@Bean
	public TaskExecutor taskExecutor() {
		SimpleAsyncTaskExecutor asyncTaskExecutor = new SimpleAsyncTaskExecutor("spring_batch");
		asyncTaskExecutor.setConcurrencyLimit(3);  // Limita a 3 hilos simultaneos
		return asyncTaskExecutor;
	}
	
		
	@Bean
	public Flow flow1() {
		return new FlowBuilder<SimpleFlow>("flow1")
				.start(step1())
				.build();
	}
	
	@Bean
	public Flow flow2() {
		return new FlowBuilder<SimpleFlow>("flow2")
				.start(step2())
				.build();
	}
	
	@Bean
	public Flow flow3() {
		return new FlowBuilder<SimpleFlow>("flow3")
				.start(step3())
				.build();
	}
}








