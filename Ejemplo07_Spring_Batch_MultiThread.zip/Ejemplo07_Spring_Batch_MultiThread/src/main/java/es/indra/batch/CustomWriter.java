package es.indra.batch;

import java.util.List;

import org.springframework.batch.item.ItemWriter;

import es.indra.models.Producto;

public class CustomWriter implements ItemWriter<Producto>{

	@Override
	public void write(List<? extends Producto> productos) throws Exception {
		
		for (Producto producto : productos) {
			System.out.println("Escribiendo producto: " + producto);
		}
		
		
	}

}
