package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo03SpringBatchTaskletApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo03SpringBatchTaskletApplication.class, args);
	}

}
