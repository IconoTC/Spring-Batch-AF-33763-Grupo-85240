package es.indra.batch;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {
	
	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Bean
	public LoginTasklet loginTasklet() {
		return new LoginTasklet();
	}
	
	@Bean
	public ConfirmacionTasklet confirmacionTasklet() {
		return new ConfirmacionTasklet();
	}
	
	@Bean
	public PagoTasklet pagoTasklet() {
		return new PagoTasklet();
	}
	
	@Bean
	public ErrorTasklet errorTasklet() {
		return new ErrorTasklet();
	}
	
	@Bean
	public Step stepLogin() {
		return stepBuilderFactory.get("stepLogin")
				.tasklet(loginTasklet())
				.build();
	}
	
	@Bean
	public Step stepConfirmacion() {
		return stepBuilderFactory.get("stepConfirmacion")
				.tasklet(confirmacionTasklet())
				.build();
	}
	
	@Bean
	public Step stepPago() {
		return stepBuilderFactory.get("stepPago")
				.tasklet(pagoTasklet())
				.build();
	}
	
	@Bean
	public Step stepError() {
		return stepBuilderFactory.get("stepError")
				.tasklet(errorTasklet())
				.build();
	}

	// Job Secuencial
//	@Bean
//	public Job jobSecuencial() {
//		return jobBuilderFactory.get("jobSecuencial")
//				.start(stepLogin())
//				.next(stepConfirmacion())
//				.next(stepPago())
//				.build();
//	}
	
	
	// Job Condicional
//	@Bean
//	public Job jobCondicional() {
//		return jobBuilderFactory.get("jobCondicional")
//				.start(stepLogin())
//					.on("FAILED").end()
////					.on("FAILED").to(otro_step)
////					.on("CONTINUABLE").to(otro_step)
//					.on("*").to(stepConfirmacion())
//				.from(stepConfirmacion())
//					.on("FAILED").end()
//					.on("*").to(stepPago())
//				.from(stepPago())
//					.on("FAILED").end()
//				.end()
//				.build();
//									
//	}
	
	
	@Bean
	public Job jobCondicional() {
		return jobBuilderFactory.get("jobCondicional")
				.start(stepLogin())
					.on("FAILED").to(stepError())
				.from(stepLogin())
					.on("COMPLETED").to(stepConfirmacion())
					//.on("*").to(stepConfirmacion())    tambien funciona
				.from(stepError())
					.on("*").end()
				.from(stepConfirmacion())
					.on("FAILED").to(stepError())
				.from(stepConfirmacion())
					.on("*").to(stepPago())
				.from(stepPago())
					.on("FAILED").to(stepError())
				.end()
				.build();
									
	}
}








