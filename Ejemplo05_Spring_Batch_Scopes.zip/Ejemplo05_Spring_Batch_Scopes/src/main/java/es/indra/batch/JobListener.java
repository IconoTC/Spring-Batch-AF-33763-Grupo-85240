package es.indra.batch;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import es.indra.models.Producto;

public class JobListener extends JobExecutionListenerSupport{
		
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private long inicio;
	
	@Override
	public void beforeJob(JobExecution jobExecution) {
		inicio = System.currentTimeMillis();
		System.out.println("Iniciando el job ---------------------------");
	}
	

	@Override
	public void afterJob(JobExecution jobExecution) {
		if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
			jdbcTemplate.query("select * from productos", 
					(resultSet, row) -> new Producto(
							resultSet.getInt("id"), 
							resultSet.getString("descripcion"), 
							resultSet.getDouble("precio")))
				.forEach(System.out::println);
		}
		
		
		long fin = System.currentTimeMillis();
		System.out.println("Tiempo de ejecucion: " + (fin-inicio) + " mseg.");
		System.out.println("Finalizado el job ---------------------------");
	}

	
	
	

}
