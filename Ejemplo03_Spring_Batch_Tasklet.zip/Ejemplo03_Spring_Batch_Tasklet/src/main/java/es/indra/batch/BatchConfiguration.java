package es.indra.batch;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

	@Autowired // DI
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	private MyTasklet myTasklet;

	// Crear job
	@Bean // Convierte el obj Java en un bean de Spring
	public Job crearJob() {
		return jobBuilderFactory.get("taskletJob")
				.start(step1())
				.build();
	}

	// Crear step
	@Bean
	public Step step1() {
		return  stepBuilderFactory.get("step1")
				.tasklet(myTasklet)
				.build();
	}

}
