package es.indra.batch;

import org.springframework.batch.item.ItemProcessor;

import es.indra.models.Producto;

public class ProcesoProducto implements ItemProcessor<Producto, Producto>{

	@Override
	public Producto process(Producto producto) throws Exception {
		// Aplicamos un 10% de dto en el precio del producto
		// La descripcion la cambiamos a mayusculas
		
		double precio = producto.getPrecio() * 0.9;
		String descripcion = producto.getDescripcion().toUpperCase();
		
		Producto productoOutput = new Producto(producto.getId(), descripcion, precio);
		System.out.println("Producto entrada: " + producto);
		System.out.println("Producto salida: " + productoOutput);
		
		return productoOutput;
	}

}
