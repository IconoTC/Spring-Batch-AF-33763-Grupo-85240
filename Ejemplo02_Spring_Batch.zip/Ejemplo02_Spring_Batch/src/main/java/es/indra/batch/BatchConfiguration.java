package es.indra.batch;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {
	
	// Crear un job
	
	// Crear un step
	
	// Crear el reader
	
	// Crear un procesor
	
	// Crear el writer

}
