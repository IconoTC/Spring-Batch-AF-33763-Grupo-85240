package es.indra;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/* Todas las clases anotadas con alguna de las siguientes: Spring genera un bean y lo mete en el contenedor
 * 		@Service; clases de servicio y logica de negocio
 * 		@Repository;  repositorio de datos (dao, ldap, erp, crm)
 * 		@Controller;  Java Web tenemos los servlet pero en Spring MVC tenemos los controlllers
 * 		@Component; cuando no es ninguna de las anteriores
 * */

@Component
public class TareaProgramada {
	
	@Scheduled(fixedRate = 1000)
	public void mostrarMensaje() {
		System.out.println("Bienvenidos al curso de Spring Batch");
	}

}
