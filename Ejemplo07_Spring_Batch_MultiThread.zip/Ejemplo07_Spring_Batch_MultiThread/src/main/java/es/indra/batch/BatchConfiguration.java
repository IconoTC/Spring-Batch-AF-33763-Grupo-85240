package es.indra.batch;



import java.util.Arrays;
import java.util.List;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;

import es.indra.models.Producto;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {
	
	@Autowired  // DI
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	// Crear un job
	@Bean   // convierte el objeto Java en un bean de Spring
	public Job crearJob() {
		return jobBuilderFactory.get("productosJob")
				.start(step1())
				.build();
	}
	
	// Crear un step
	@Bean
	public Step step1() {
		return stepBuilderFactory.get("step1")
				.<Producto, Producto>chunk(2)   // nº de registros que leemos en cada bloque
				.reader(customReader())
				.writer(customWriter())
				.taskExecutor(taskExecutor())
				.throttleLimit(5)
				.build();
	}
	
	@Bean
	public TaskExecutor taskExecutor() {
		SimpleAsyncTaskExecutor asyncTaskExecutor = new SimpleAsyncTaskExecutor("spring_batch");
		asyncTaskExecutor.setConcurrencyLimit(3);  // Limita a 3 hilos simultaneos
		return asyncTaskExecutor;
	}
	
		
	// Crear el reader
	@Bean
	public ItemReader<Producto> customReader(){
		List<Producto> lista = Arrays.asList(
				new Producto(1, "aaaaaa", 10),
				new Producto(2, "bbbbbb", 20),
				new Producto(3, "cccccc", 30),
				new Producto(4, "dddddd", 40),
				new Producto(5, "eeeeee", 50)
				);
		return new CustomReader(lista);
	}
	
	
	// Crear el writer
	@Bean 
	public ItemWriter<Producto> customWriter(){
		return new CustomWriter();
	}
	

}








